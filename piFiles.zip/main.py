#
import RPi.GPIO as GPIO
import subprocess
#import datetime
import board
import busio
import adafruit_gps
import time
import serial
import request

import serial
uart = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=3000)
GPIO.setmode(GPIO.BCM)
ser = serial.Serial('/dev/ttyACM0',9600)
# Create a GPS module instance.
gps = adafruit_gps.GPS(uart, debug=False)
gps.send_command(b'PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0')
gps.send_command(b'PMTK220,1000')
last_print = time.monotonic()

GPIO.setwarnings(False)
#GPIO.setmode(GPIO.BOARD)  


#gpio pin setup
GPIO.setup(20,GPIO.OUT, initial = 0)
GPIO.setup(16,GPIO.OUT, initial = 0)
GPIO.setup(21,GPIO.IN, pull_up_down = GPIO.PUD_DOWN)

timeStamp = time.localtime()
lati = 35.9643991
longi = -83.9178213

while True:
    gps.update()
    while ser.in_waiting:
        issue = ser.readline()
        print(issue)
    #input("")
    if GPIO.input(21) == GPIO.HIGH:
        
        GPIO.output(20,GPIO.HIGH)
     
        for x in range(0,3):  
            if not gps.has_fix:
                print('Waiting for fix...')
                gps.update()
                time.sleep(4)
            else:
                lati = gps.latitude
                longi = gps.longitude
               # print('Latitude: {0:.6f} degrees'.format(gps.latitude))
               # print('Longitude: {0:.6f} degrees'.format(gps.longitude)
                x = 3;
    #    issue = input("Issue: ")
        time.sleep(1)
        timeStamp = str(time.time())
        fileName = timeStamp + ".jpeg"
        subprocess.run(("fswebcam " + fileName).split())
        request.uploadImage(fileName, longi, lati, timeStamp, issue)
        GPIO.output(20,GPIO.LOW)
        GPIO.output(16,GPIO.HIGH)
        time.sleep(1)
        GPIO.output(16,GPIO.LOW)

        
GPIO.cleanup()
