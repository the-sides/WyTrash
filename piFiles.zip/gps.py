
import time
import board
import busio
import adafruit_gps
import serial

from time import sleep


class gpsBoard:


    uart = serial.Serial("/dev/ttyS0",baudrate=9600,timeout=3000)
    gps = adafruit_gps.GPS(uart,debug=False)

    def __init__(self):
        self.gps.send_command(b'PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0')
        self.gps.send_command(b'PMTK220,1000')
        

    def getCoords(self):

        self.gps.update()

        
        while not self.gps.has_fix:
            
            print('waiting for fix')
            sleep(1)
            self.gps.update()
        
        print('=' * 40) #print line seperator
        print('Fix timestap: {}/{}/ {:02}:{:02}:{:02}'.format(
            self.gpstimestap_utc.tm_mon,
            self.gpstimestap_utc.tm_mday,
            self.gpstimestap_utc.tm_year,
            self.gpstimestap_utc.tm_hour,
            self.gpstimestap_utc.tm_min,
            self.gpstimestap_utc.tm_sec,))

        print('Latitude: {0:,6f} degrees'.format(self.gps.latitude))
        print('Longitude: {0:.6f} degrees'.format(self.gps.longitude))
        print('Fix quality: {}'.format(self.gps.fix_quality))



test = gpsBoard()


while True:
    test.getCoords()

