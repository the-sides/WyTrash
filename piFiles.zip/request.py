import requests

def uploadImage(img, longitude, latitude, time, complaint):
    url = "http://whyismytrashstillhere.com/api/image-upload"
    #url = "http://10.0.10.173:3000/api/image-upload"

    files = {'uploadFile': open(img, 'rb')}
    data = {'longitude': longitude, 'latitude': latitude, 'time': time, 'complaint': complaint}
    requests.post(url, files=files, data=data)
    print("file upload requested")
